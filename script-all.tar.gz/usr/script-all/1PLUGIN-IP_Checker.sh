#!/bin/sh
#

cd /tmp
rm -rf * > /dev/null 2>&1
cd ..
rm -rf /usr/lib/enigma2/python/Plugins/Extensions/IP-Checker

###########################
wget -O /var/volatile/tmp/ip_checker_all.ipk "https://raw.githubusercontent.com/emil237/plugins/main/ip_checker_all.ipk"
wait
opkg install --force-overwrite /tmp/*.ipk
wait
rm -f /var/volatile/tmp/ip_checker_all.ipk
wait
echo">>>>>>UPLOADED BY EMIL_NABIL <<<<<<<"
sleep 2;
wait
killall -9 enigma2
exit 0











           
