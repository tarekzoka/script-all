
#!/bin/sh
#

wget -O /var/volatile/tmp/Skin-My-Vali-HD-nano-By-Vali-MOD-RAED.ipk "https://raw.githubusercontent.com/emil237/skins-OpenPli/main/Skin-My-Vali-HD-nano-By-Vali-MOD-RAED.ipk"
wait
opkg install --force-overwrite /tmp/*.ipk
wait
rm -f /var/volatile/tmp/Skin-My-Vali-HD-nano-By-Vali-MOD-RAED.ipk
wait
sleep 2;
exit 0

