opkg install --force-overwrite  https://raw.githubusercontent.com/emilnabil/emil_script_package/main/skins-nitro-green-wood-fhd_v3.0_all.ipk
wait
sleep 2;
exit 0













