#!/bin/sh

wget -q "--no-check-certificate" https://gitlab.com/eliesat/display/-/raw/main/city/bootlogos-city.sh -O - | /bin/sh 

exit 0