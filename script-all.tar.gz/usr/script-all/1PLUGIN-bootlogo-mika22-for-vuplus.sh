opkg install --force-overwrite  http://178.63.156.75/paneladdons/Pluginsoe20/bootlogos/enigma2-plugin-extensions-bootlogo-mika22-for-vuplus-only_0.4_all.ipk
wait
sleep 2;
exit



