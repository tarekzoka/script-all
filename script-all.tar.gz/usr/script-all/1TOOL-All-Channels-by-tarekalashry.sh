#!/bin/sh
#

wget -O /media/hdd/channels_backup_tarekalashry.tar.gz "https://github.com/emilnabil/emil_script_package/raw/main/channels_backup_tarekalashry.tar.gz"
wait
wget -O /var/volatile/tmp/channels_backup_tarekalashry.tar.gz "https://github.com/emilnabil/emil_script_package/raw/main/channels_backup_tarekalashry.tar.gz"
wait
tar xzvpf /tmp/channels_backup_tarekalashry.tar.gz  -C /
wait
rm -r /var/volatile/tmp/channels_backup_tarekalashry.tar.gz
wait
sleep 2;
init 4
sleep 1
init 3


























