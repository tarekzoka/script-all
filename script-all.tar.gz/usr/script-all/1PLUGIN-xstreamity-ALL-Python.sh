wget https://raw.githubusercontent.com/biko-73/xstreamity/main/installer.sh -O - | /bin/sh




