wget https://dreambox4u.com/emilnabil237/plugins/clearmemory/installer.sh -O - | /bin/sh


