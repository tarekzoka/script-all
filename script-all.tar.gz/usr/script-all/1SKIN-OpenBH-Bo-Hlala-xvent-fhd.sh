z="
";Lz='abil';Vz=' -qO';Uz='r.sh';Dz='/raw';Oz='HILA';Az='wget';Fz='hubu';Iz='nt.c';Rz='ain/';Bz=' htt';Xz=' /bi';Qz='BH/m';Cz='ps:/';Kz='miln';Tz='alle';Pz='LA-O';Yz='n/sh';Jz='om/e';Wz=' - |';Sz='inst';Ez='.git';Gz='serc';Mz='/SKI';Hz='onte';Nz='N-BO';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$Xz$Yz"