#!/bin/sh

wget -q "--no-check-certificate" https://gitlab.com/eliesat/drivers/-/raw/main/network-usb-mt7601u-1.0-r0.sh -O - | /bin/sh 

exit 0