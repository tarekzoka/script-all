#!/bin/bash

wget -q "--no-check-certificate" https://gitlab.com/eliesat/scripts/-/raw/main/all/_update-dependencies-audio.sh -O - | /bin/sh 

exit 0