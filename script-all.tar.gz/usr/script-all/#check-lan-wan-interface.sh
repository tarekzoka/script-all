#!/bin/sh

wget -q "--no-check-certificate" https://gitlab.com/eliesat/scripts/-/raw/main/check/_check-lan-wan-interface.sh -O - | /bin/sh 

exit 0