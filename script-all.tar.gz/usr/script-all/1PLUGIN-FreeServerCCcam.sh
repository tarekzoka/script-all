wget https://raw.githubusercontent.com/biko-73/FreeServerCCcam/main/installer.sh -qO - | /bin/sh




