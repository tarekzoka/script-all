wget https://dreambox4u.com/emilnabil237/plugins/tspanel/installer.sh -O - | /bin/sh



