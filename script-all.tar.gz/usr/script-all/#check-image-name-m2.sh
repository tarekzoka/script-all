#!/bin/sh

wget -q "--no-check-certificate" https://gitlab.com/eliesat/scripts/-/raw/main/check/_check-image-name-m2.sh -O - | /bin/sh 

exit 0