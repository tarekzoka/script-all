
#!/bin/sh
#

wget -O /var/volatile/tmp/Skin-OSN-BLACK-FHD-By-Muaath.ipk "https://raw.githubusercontent.com/emil237/skins-openatv/main/Skin-OSN-BLACK-FHD-By-Muaath.ipk"
wait
opkg install --force-overwrite /tmp/*.ipk
wait
rm -f /var/volatile/tmp/Skin-OSN-BLACK-FHD-By-Muaath.ipk
wait
sleep 2;
exit 0












