#!/bin/sh

opkg install wget  

exit 0