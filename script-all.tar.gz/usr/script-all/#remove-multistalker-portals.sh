#!/bin/sh

wget -q "--no-check-certificate" https://gitlab.com/eliesat/scripts/-/raw/main/remove/_remove-multistalker-portals.sh -O - | /bin/sh 

exit 0