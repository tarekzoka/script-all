wget https://raw.githubusercontent.com/biko-73/TSmedia/main/installer.sh -O - | /bin/sh
