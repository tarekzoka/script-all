#!/bin/sh

wget -q "--no-check-certificate" https://gitlab.com/eliesat/display/-/raw/main/vu+/bootlogos-vu+-1.0.tar.gz -O - | /bin/sh 

exit 0