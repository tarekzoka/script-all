#!/bin/sh

wget -q "--no-check-certificate" https://gitlab.com/eliesat/scripts/-/raw/main/all/_hdd-intialize-ext4.sh -O - | /bin/sh 

exit 0