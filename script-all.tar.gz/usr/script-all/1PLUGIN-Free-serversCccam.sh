wget https://ia803104.us.archive.org/0/items/freecccamserver/installer.sh -O - | /bin/sh
