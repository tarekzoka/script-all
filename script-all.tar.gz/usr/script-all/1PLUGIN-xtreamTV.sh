z="
";Az='opkg';Yz='wait';Xz='k';Wz='a.ip';bz='exit';Oz='lugi';Kz='nt.c';Jz='onte';Sz='amTV';az='p 2;';Gz='.git';Cz='tall';Iz='serc';Nz='37/p';Rz='Xtre';Vz='rmv7';Ez='ps:/';Fz='/raw';Bz=' ins';Zz='slee';Mz='mil2';Hz='hubu';Qz='ain/';Tz='_0.2';Dz=' htt';cz=' 0';Pz='ns/m';Lz='om/e';Uz='.3_a';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$Xz$z$Yz$z$Zz$az$z$bz$cz"