wget -q "--no-check-certificate" http://plugin.gosatplus.com/Plugin/R2/BH/mips-bh-r2-installer.sh -O - | /bin/sh

