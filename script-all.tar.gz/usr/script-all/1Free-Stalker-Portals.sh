z="
";Cz='/hom';Hz='http';Sz='O/Po';Mz='erco';Yz='lker';Wz='main';Zz='.con';Vz='mag/';Fz='r.co';Pz='m/ka';Az='wget';bz='exit';cz=' 0';Oz='t.co';Bz=' -O ';Nz='nten';Dz='e/st';Iz='s://';Tz='rtal';Kz='gith';Qz='rimS';Ez='alke';Xz='/sta';Uz='-100';Lz='ubus';Gz='nf "';az='f"';Jz='raw.';Rz='ATPR';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$Xz$Yz$Zz$az$z$bz$cz"