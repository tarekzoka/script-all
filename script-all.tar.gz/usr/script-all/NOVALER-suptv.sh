wget -q "--no-check-certificate" https://dreambox4u.com/emilnabil237/plugins/novalerstore/suptv/suptv.sh -O - | /bin/sh


