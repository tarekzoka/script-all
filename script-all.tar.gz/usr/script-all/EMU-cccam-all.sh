wget https://dreambox4u.com/emilnabil237/emu/installer-cccam.sh -O - | /bin/sh



