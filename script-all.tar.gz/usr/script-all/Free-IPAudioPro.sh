wget https://dreambox4u.com/emilnabil237/script/audio-ipaudiopro.sh -O - | /bin/sh

