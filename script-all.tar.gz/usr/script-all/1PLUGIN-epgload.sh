#!/bin/sh
#

wget -O /var/volatile/tmp/epgload_0.96_all.ipk "https://raw.githubusercontent.com/emilnabil/emil_script_package/main/epgload_0.96_all.ipk"
wait
opkg install --force-overwrite /tmp/*.ipk
wait
rm -f /var/volatile/tmp/epgload_0.96_all.ipk
wait
sleep 2;
exit 0











