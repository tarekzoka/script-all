wget  --no-check-certificate https://dreambox4u.com/emilnabil237/images/vti-15.0.02.sh -O - | /bin/sh
exit 0
