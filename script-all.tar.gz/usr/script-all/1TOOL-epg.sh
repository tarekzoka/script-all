#!/bin/sh
#

wget -O /etc/epgimport/ar_osn.xmltv "https://raw.githubusercontent.com/Fazzani/grab/master/ar_osn.xmltv"
wget -O /etc/epgimport/ar_osn2.xmltv "https://raw.githubusercontent.com/Fazzani/grab/master/ar_osn2.xmltv"
wget -O /etc/epgimport/ar_osn3.xmltv "https://raw.githubusercontent.com/Fazzani/grab/master/ar_osn3.xmltv"
wget -O /etc/epgimport/ar_osn4.xmltv "https://raw.githubusercontent.com/Fazzani/grab/master/ar_osn4.xmltv"
wget -O /etc/epgimport/ar_osn5.xmltv "https://raw.githubusercontent.com/Fazzani/grab/master/ar_osn5.xmltv"
wget -O /etc/epgimport/ar_arab.xmltv "https://raw.githubusercontent.com/Fazzani/grab/master/ar_arab.xmltv"
wget -O /etc/epgimport/ar_el_cinema.xmltv "https://raw.githubusercontent.com/Fazzani/grab/master/ar_el_cinema.xmltv"
wget -O /etc/epgimport/ar_bein.xmltv "https://raw.githubusercontent.com/Fazzani/grab/master/ar_bein.xmltv"
exit 0
