wget https://raw.githubusercontent.com/emil237/epanel/main/installer.sh -O - | /bin/sh



