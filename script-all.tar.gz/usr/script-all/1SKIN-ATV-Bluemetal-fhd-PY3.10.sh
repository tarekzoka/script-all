#!/bin/sh
#

wget -O /var/volatile/tmp/skins-bluemetalfhd_2.10_all.ipk "https://raw.githubusercontent.com/emil237/skins-openatv/main/skins-bluemetalfhd_2.10_all.ipk"
wait
opkg install --force-overwrite /tmp/skins-bluemetalfhd_2.10_all.ipk
wait
rm -f /var/volatile/tmp/skins-bluemetalfhd_2.10_all.ipk
wait
sleep 2;
echo "********************************************************************************"
echo "   UPLOADED BY  >>>>   EMIL_NABIL "   
sleep 4;
		echo ". >>>>         RESTARING     <<<<"
echo "**********************************************************************************"
wait
killall -9 enigma2
exit 0














