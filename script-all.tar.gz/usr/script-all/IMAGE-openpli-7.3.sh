wget  --no-check-certificate https://dreambox4u.com/emilnabil237/images/openpli-7.3.sh -O - | /bin/sh
exit 0
