#!/bin/sh

wget -q "--no-check-certificate" https://gitlab.com/eliesat/extensions/-/raw/main/multistalker/multistalker.sh -O - | /bin/sh 

exit 0