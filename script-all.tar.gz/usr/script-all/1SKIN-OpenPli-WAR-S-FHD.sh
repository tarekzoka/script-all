opkg install --force-overwrite  https://raw.githubusercontent.com/emilnabil/emil_script_package/main/Skin-WAR-S-FHD-By-Muaath.ipk
wait
sleep 2;
exit 0
