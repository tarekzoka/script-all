wget https://dreambox4u.com/emilnabil237/script/Increasing-the-number-of-portals-200.sh -O - | /bin/sh




