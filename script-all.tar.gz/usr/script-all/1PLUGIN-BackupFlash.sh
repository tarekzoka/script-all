wget http://tunisia-dreambox.info/TSplugins/backupflash/installer.sh -O - | /bin/sh


