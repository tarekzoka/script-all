#!/bin/sh

wget -q "--no-check-certificate" https://gitlab.com/eliesat/display/-/raw/main/n-image/bootlogos-n-opentr.sh -O - | /bin/sh 

exit 0