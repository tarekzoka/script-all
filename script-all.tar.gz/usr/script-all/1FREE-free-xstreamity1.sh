[ ! -d "/etc/enigma2/xstreamity/playlists.txt" ] && wget -O /etc/enigma2/xstreamity/playlists.txt https://raw.githubusercontent.com/emil237/xtreamity/main/playlists.txt

exit 0








