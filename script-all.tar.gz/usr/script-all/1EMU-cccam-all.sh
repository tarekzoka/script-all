wget https://raw.githubusercontent.com/emil237/cccam/main/installer.sh -O - | /bin/sh


