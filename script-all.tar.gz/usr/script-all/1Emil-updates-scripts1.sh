#!/bin/sh
# 
##script install FULL SCRIPTS## 
sleep 1
wget -q https://raw.githubusercontent.com/emil237/download-plugins/main/script.tar.gz -P /tmp
echo "Downloading the  FULL SCRIPTS ..."
sleep 1
if [ -f /tmp/script.tar.gz ]; then
	tar -xzf /tmp/script.tar.gz -C /
fi
sleep 1
rm -rf /tmp/script.tar.gz
echo " FULL SCRIPTS Installed..."
sleep 1
echo "e2 restarting..."
sleep 1
killall -9 enigma2
exit 0



