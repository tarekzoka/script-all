wget -O /home/stalker.conf "https://raw.githubusercontent.com/karimSATPRO/Portal-100mag/main/stalker.conf"
exit 0
