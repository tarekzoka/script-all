wget -O /var/volatile/tmp/enigma2-plugin-extensions-epgimport_1.0+git210+20190625_all.ipk "https://raw.githubusercontent.com/emilnabil/emil_script_package/main/enigma2-plugin-extensions-epgimport_1.0%2Bgit210%2B20190625_all.ipk"
wait
opkg install --force-overwrite /tmp/*.ipk
wait
rm -f /var/volatile/tmp/enigma2-plugin-extensions-epgimport_1.0+git210+20190625_all.ipk
wait
sleep 2;
exit 0




















