
#!/bin/sh
#

wget -O /var/volatile/tmp/pluginsort_0.1.ipk "https://raw.githubusercontent.com/emil237/plugins/main/pluginsort_0.1.ipk"
wait
opkg install --force-overwrite /tmp/pluginsort_0.1.ipk
wait
rm -f /var/volatile/tmp/pluginsort_0.1.ipk
wait
sleep 2;
echo "   UPLOADED BY  >>>>   EMIL_NABIL "   
sleep 4;
	echo '========================================================================================================================='
###########################################                                                                                                                  
echo ". >>>>         RESTARING     <<<<"
echo "**********************************************************************************"
wait
killall -9 enigma2
exit 0











