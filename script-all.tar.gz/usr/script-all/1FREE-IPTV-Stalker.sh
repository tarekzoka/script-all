#!/bin/sh
#

wget -O /home/stalker.conf "https://drive.google.com/uc?id=1PR5ewrXpX5CEwDIRh_0UKD388MUVwc9A&export=download" && killall -9 enigma2

exit 0










