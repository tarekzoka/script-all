wget  --no-check-certificate https://dreambox4u.com/emilnabil237/images/BlackHole-3.1.0.sh -O - | /bin/sh
exit 0
