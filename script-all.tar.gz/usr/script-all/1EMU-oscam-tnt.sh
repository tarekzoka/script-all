#!/bin/sh
echo "Installing emu-oscam-tnt "
sleep 1
cd /tmp
curl  -k -Lbk -m 55532 -m 555104 "https://raw.githubusercontent.com/emil237/plugins/main/oscam-tnt_11.678-tnt_all.ipk" > /tmp/oscam-tnt_11.678-tnt_all.ipk
sleep 1
echo "install emu-oscam-tnt...."
cd /tmp
opkg install /tmp/oscam-tnt_11.678-tnt_all.ipk
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
sleep 1
rm /tmp/oscam-tnt_11.678-tnt_all.ipk
sleep 2
exit 0















