[ ! -d "/etc/enigma2/jediplaylists/playlists.txt" ] && wget -O /etc/enigma2/jediplaylists/playlists.txt https://raw.githubusercontent.com/emil237/jedimakerxtream/main/playlists.txt

exit 0












