
#!/bin/sh
#

wget -O /var/volatile/tmp/tunisiaaddon_01_all.ipk "https://raw.githubusercontent.com/emilnabil/emil_script_package/main/tunisiaaddon_01_all.ipk"
wait
opkg install --force-overwrite /tmp/*.ipk
wait
rm -f /var/volatile/tmp/tunisiaaddon_01_all.ipk
wait
sleep 2;
exit 0













