#!/bin/sh

wget -q "--no-check-certificate" https://gitlab.com/eliesat/scripts/-/raw/main/remove/_remove-emus-config-files.sh -O - | /bin/sh 

exit 0