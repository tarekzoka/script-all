wget https://raw.githubusercontent.com/biko-73/jediepgxtream/main/installer.sh -O - | /bin/sh
