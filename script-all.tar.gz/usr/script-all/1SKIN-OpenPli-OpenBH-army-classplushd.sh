
#!/bin/sh
#

wget -O /var/volatile/tmp/Skin-Army-ClassPlusHD_OpenPLi6-all.ipk "https://raw.githubusercontent.com/emil237/skins-OpenPli/main/Skin-Army-ClassPlusHD_OpenPLi6-all.ipk"
wait
opkg install --force-overwrite /tmp/*.ipk
wait
rm -f /var/volatile/tmp/Skin-Army-ClassPlusHD_OpenPLi6-all.ipk
wait
sleep 2;
exit 0






























