wget  --no-check-certificate https://dreambox4u.com/emilnabil237/images/openblackhole-5.0.sh -O - | /bin/sh
exit 0
