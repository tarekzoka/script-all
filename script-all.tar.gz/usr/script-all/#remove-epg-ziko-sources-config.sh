#!/bin/sh

wget -q "--no-check-certificate" https://gitlab.com/eliesat/scripts/-/raw/main/remove/_remove-epg-ziko-sources-config.sh -O - | /bin/sh 

exit 0