#!/bin/sh

wget -q "--no-check-certificate" https://gitlab.com/eliesat/extensions/-/raw/main/lamedbmerger/lamedbmerger.sh -O - | /bin/sh 

exit 0