opkg install --force-overwrite  https://raw.githubusercontent.com/emilnabil/emil_script_package/main/skins-aeonfhd_all.ipk
wait
sleep 2;
exit 0







