#!/bin/sh
#

wget -O /usr//lip/enigma2/python/OPENDROID/BluePanel.pyo "https://raw.githubusercontent.com/emil237/plugins/main/BluePanel.pyo"

exit 0






