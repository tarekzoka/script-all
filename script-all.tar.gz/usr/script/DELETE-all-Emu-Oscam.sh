opkg remove enigma2-plugin-softcams-oscam*

