wget http://dreambox4u.com/emilnabil237/plugins/ansite/installer.sh -qO - | /bin/sh



