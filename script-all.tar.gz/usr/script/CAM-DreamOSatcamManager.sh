wget https://dreambox4u.com/emilnabil237/plugins/dreamosatcammanager/installer.sh -O - | /bin/sh




