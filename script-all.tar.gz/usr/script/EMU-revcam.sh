wget https://dreambox4u.com/emilnabil237/emu/installer-revcam.sh -O - | /bin/sh



